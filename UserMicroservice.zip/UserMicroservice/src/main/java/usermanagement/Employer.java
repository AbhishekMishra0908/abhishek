package usermanagement;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;
//import javax.persistence.Table;


@Entity/*(name="Employer")*/
@Table(name="employer")
@DiscriminatorValue("EMPLOYER")

public class Employer extends User
{
	@Column(name="company_name")
private String companyName;
	@Column(name="company_details")
private String companyDetails;
public Employer() 
{
	
}

public Employer(String companyName, String companyDetails) 
{
	super();
	this.companyName = companyName;
	this.companyDetails = companyDetails;
}
public String getCompanyName()
{
	return companyName;
}
public void setCompanyName(String companyName) 
{
	this.companyName = companyName;
}
public String getCompanyDetails() 
{
	return companyDetails;
}
public void setCompanyDetails(String companyDetails) 
{
	this.companyDetails = companyDetails;
}

}
