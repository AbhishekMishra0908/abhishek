package usermanagement;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;



@Service
public class UserManagementService implements UserManagementMicroservice
{
@Autowired
private Userrepo userrepo;

	@Override
	public boolean login(String id, String password) 
	{
	User user = userrepo.finduser(id, password);
	if(user !=null && user.getPassword()!= null) 
	{
		user.getPassword().equals(password);
	return true;
}

	return false;

	}
	public boolean  loginNative(String id, String password)
	{
		User user = getUser(id);
		if(user !=null && user.getPassword()!= null) 
		{
			user.getPassword().equals(password);
		return true;
	}

		return false;
		}
	

	@Override
	public boolean register(User user) 
	{
		 
	 return userrepo.save(user) != null ;
		    
	}
	@Override

	public User UpdateProfile(User user) {
		if(user.getId()<=0)
			return null;
		userrepo.save(user);
		return user;}
	/*public User UpdateProfile(User user1) 
	{
		return userrepo.save(user1);
		
	}*/

@Override
	public User getUser(String id) 
{
	
		User user = userrepo.finduser(id);
		return user;
	}

	
	@Override
	
	public List<Candidate> getAllcandidates()
	{
		
		return userrepo.findAllCandidates();
	}
	
public List<User> getAllUsers()
{ 
		
		return userrepo.findAll() ;
	}

	public List<Employer> getAllEmployers() {
		
		return userrepo.findAllEmployer();
	}
	

}
