package usermanagement;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
@Entity
@Table(name="useraccount")
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)//The single table strategy maps all entities of the inheritance structure to the same database table.
@DiscriminatorColumn(name = "Usertype", discriminatorType = DiscriminatorType.STRING,columnDefinition= "VARCHAR(10")

		
		
		
public class User {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
private int id;
	@Column(name="name")
private String name;
	@Column(name="email")
private String email;
	@Column(name="password")
private String password;
	@Column(name="address")
private String address;
	@Column(name="mobile")
private String mobile;
public User()
{

}

public User( String name, String email, String password, String address, String mobile) 
{
	super();

	this.name = name;
	this.email = email;
	this.password = password;
	this.address = address;
	this.mobile = mobile;
}
public int getId()
{
	return id;
}
public void setId(int id) 
{
	this.id = id;
}
public String getName()
{
	return name;
}
public void setName(String name) 
{
	this.name = name;
}
public String getEmail() 
{
	return email;
}
public void setEmail(String email) 
{
	this.email = email;
}
public String getPassword()
{
	return password;
}
public void setPassword(String password) 
{
	this.password = password;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) 
{
	this.address = address;
}
public String getMobile() 
{
	return mobile;
}
public void setMobile(String mobile)
{
	this.mobile = mobile;
}

@Override
public String toString() {
	    return "User [name=" + name + ", id=" + id + 
                ", mobile=" + mobile + ", email=" + email + ",password="+ password+",address=" + address +"]";
    }

    }



