package registry;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {
@Autowired
RestTemplate resttemplate;

		public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		ApplicationUser user1 =  resttemplate.getForObject("http://localhost:8080/user-service/users/list", ApplicationUser.class);
		user1.getUsername();
		user1.getPassword();
		return  (UserDetails) user1;
	
    }
}
	
/*	
	ResponseEntity<ApplicationUser[]> response1 =
			  resttemplate.getForEntity(
			  "http://localhost:8089/users/list/",
			  ApplicationUser[].class);
			ApplicationUser[] applicationUser= response1.getBody();
		  return new User(applicationUser.getUsername(), applicationUser.getPassword());
		
	


}

	*/
	
	
	