package notification;

public interface NotificationMicroserv {
public void notify(String id, String message);

}
