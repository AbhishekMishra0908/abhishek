package job;



import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;





@Entity

@Table(name="job")
public class Job
{
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
private int id;

	@Column(name="description")
@Size(min=100)
private String description;
	
	
	@Column(name="experience")
private String experience;
	@Column(name="location")
private String location;
	@Column(name="salary")
	@Size(min=4)
private String salary;
	@Column(name="created",nullable = false, updatable = false)
	@CreationTimestamp
	 
	    private LocalDateTime createDateTime;
	 @Column(name="updated")
	    @UpdateTimestamp
	   
	    private LocalDateTime updateDateTime;
	 @OneToMany(cascade=CascadeType.ALL,orphanRemoval=true)
	 @JoinColumn(name="job_id")

	  private Set<JobServiceApplication> jobserv= new HashSet<JobServiceApplication>();
	 
public Set<JobServiceApplication> getJobserv() {
		return jobserv;
	}
	public void setJobserv(Set<JobServiceApplication> jobserv) {
		this.jobserv = jobserv;
	}
public LocalDateTime getCreateDateTime() {
		return createDateTime;
	}
	public void setCreateDateTime(LocalDateTime createDateTime) {
		this.createDateTime = createDateTime;
	}
	public LocalDateTime getUpdateDateTime() {
		return updateDateTime;
	}
	public void setUpdateDateTime(LocalDateTime updateDateTime) {
		this.updateDateTime = updateDateTime;
	}


public int getId()

{
	return id;
}
public void setId(Integer id)
{
	this.id = id;
}

public String getDescription()
{
	return description;
}
public void setDescription(String description)
{
	this.description = description;
}
public String getExperience()
{
	return experience;
}
public void setExperience(String experience)
{
	this.experience = experience;
}
public String getLocation()
{
	return location;
}
public void setLocation(String location) 
{
	this.location = location;
}
public String getSalary() 
{
	return salary;
}
public void setSalary(String salary)
{
	this.salary = salary;
}

}
