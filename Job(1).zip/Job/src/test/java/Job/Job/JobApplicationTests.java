package Job.Job;

import org.junit.Test;
import org.junit.runner.RunWith;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)

@ComponentScan(basePackages= {"Job.Job"})
public class JobApplicationTests {

	@Test
	public void contextLoads() {
	}

}
