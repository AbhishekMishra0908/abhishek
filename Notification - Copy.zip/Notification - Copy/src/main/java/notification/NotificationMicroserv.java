package notification;

public interface NotificationMicroserv {
	public void notify(String email);
}
