package notification;





import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.web.client.RestTemplate;
@EnableEurekaClient
@EnableDiscoveryClient
@EnableAutoConfiguration
@ComponentScan("notification")
@SpringBootApplication


public class NotificationMicroserviceApplication {
	public static void main(String[] args) {
		SpringApplication.run(NotificationMicroserviceApplication.class, args);
	}
	@LoadBalanced
	@Bean
	public JavaMailSender getJavaMailSender() {
	    JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
	    
	     
	    return mailSender;
	}
	
	
	@Bean
	public RestTemplate getRestTemplate() {
		return new RestTemplate();
		
	
	}

}
