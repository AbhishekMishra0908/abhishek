package notification;



	/*import java.awt.List;
	import java.util.ArrayList;

	import javax.mail.internet.InternetAddress;
	import javax.validation.constraints.Email;
	*/
	//import java.util.List;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.mail.SimpleMailMessage;
	import org.springframework.mail.javamail.JavaMailSender;
	import org.springframework.stereotype.Component;
	//import org.springframework.messaging.simp.SimpMessagingTemplate;


	//import it.ozimov.springboot.mail.model.defaultimpl.DefaultEmail;
	/*@Service
	public class Notificationservice  implements NotificationMicroserv{
	@Autowired
		private JavaMailSender javamailsender;
	@Autowired
	private UserInformation userinfo;
		@Override
		public void notify(String email, String message) {

		 SimpleMailMessage msg = new SimpleMailMessage();
		 msg.setTo(userinfo.getEmail(),message);

	       msg.setSubject("Testing from Spring Boot");
	        msg.setText("Hello World \n Spring Boot Email");

		        javamailsender.send(msg);

		    }*/
		
		
		@Component
		public class NotificationService implements NotificationMicroserv{
		  
		    @Autowired
		    public JavaMailSender emailSender;
		 
		    
		    

			@Override
			public void notify(String email) {
				SimpleMailMessage message1 = new SimpleMailMessage(); 
				message1.setTo();
				message1.setSubject("hello");
				message1.setText("simple mail sending");
				
			}
		 
			/*UserInformation userinfo = new UserInformation(); 
	userinfo.setEmail("pom45747@gmail.com"); 

	final Email email = DefaultEmail.builder() 
	    .from(new InternetAddress("From Name"))
	 
	    .to(lists.newArrayList(new InternetAddress(
	        userinfo.getEmail()))) 
	    .subject("Testing email")
	    .body("Testing body ...")
	    .encoding("UTF-8").build();
	*/
	}
		

		/*@Override
		public void notify(String id, String message) {
		
			
		}

	@Autowired
	private SimpMessagingTemplate messagingTemplate;
		@Override
		public void notify(String id, String message) {
			messagingTemplate.convertAndSendToUser(
				      id, 
				      "/queue/notify", 
				      message
				    );
				    return;
				  }
			
		

		}


	*/

