package notification;


	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.http.ResponseEntity;
	import org.springframework.stereotype.Service;
	import org.springframework.web.client.RestTemplate;

	import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
	import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

	@Service("userservicedel")
	public class UserserviceDelegate {
		
	@Autowired 
	RestTemplate resttemplate;
	 @HystrixCommand(fallbackMethod= "callUserServiceAndGetData_Fallback",
			 commandProperties = {
			          @HystrixProperty(name = "circuitBreaker.requestVolumeThreshold", value = "2"),
			          @HystrixProperty(name = "metrics.rollingStats.timeInMilliseconds", value = "500"),
			          @HystrixProperty(name = "circuitBreaker.errorThresholdPercentage", value = "1"),
			          @HystrixProperty(name = "circuitBreaker.sleepWindowInMilliseconds", value = "1000")

			  })
	
		 
	 
	public UserInformation getUserDetails(int id) {
		ResponseEntity<UserInformation> responseEntity =  resttemplate.getForEntity(
				"http://localhost:8089/users/list" + id,UserInformation.class
				);
		
		UserInformation response = responseEntity.getBody();
		
		return response;
	 }
		@SuppressWarnings("unused")
		private UserInformation callUserServiceAndGetData_Fallback(int id) {
			System.out.println("user service is down");
		return null;
		
		}
	}


	/*package notification;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.http.ResponseEntity;
	import org.springframework.stereotype.Service;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.client.RestTemplate;

	@Service
	public class UserserviceDelegate {
		
		@Autowired
		private RestTemplate restTemplate;
		
		@RequestMapping("/sendnotification")
		public ResponseEntity<UserInformation> getUserDetails(int id) {
			ResponseEntity<UserInformation> responseEntity = restTemplate.getForEntity(
					"http://localhost:8056/usermanagement/user/" +id,UserInformation.class
					);
		
			return responseEntity;
		 
		
		
	}}*/



