package usermanagement;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;



@Service
public class UserManagementService implements UserManagementMicroservice
{
@Autowired
private Userrepo userrepo;


	@Override
	public boolean login(String email, String password) 
	{
	User user = userrepo.finduser(email, password);
	if(user !=null && user.getPassword()!= null) 
	{
		user.getPassword().equals(password);
	return true;
}

	return false;

	}
	/*public boolean  loginNative(String userid, String password)
	{
		User user = getUser(userid);
		if(user !=null && user.getPassword()!= null) 
		{
			user.getPassword().equals(password);
		return true;
	}

		return false;
		}
	
*/
	@Override
	public boolean register(User user) 
	{
		 
	 return userrepo.save(user) != null ;
		    
	}
	
	public boolean registercan(Candidate candidate) 
	{
		 
	 return userrepo.save(candidate) != null ;
		    
	}

	public boolean registeremp(Employer employer) 
	{
		 
	 return userrepo.save(employer) != null ;
		    
	}
	@Override

	public User UpdateProfile(User user) {
		if(user.getId()<=0)
			return null;
		userrepo.save(user);
		return user;}
	/*public User UpdateProfile(User user1) 
	{
		return userrepo.save(user1);
		
	}*/

@Override
/*	public User getUser(String userid) 
{
	
		User user = userrepo.finduser(userid);
		return user;
	}*/
public User getUser(Integer id) {
	
    java.util.Optional<User> user = userrepo.findById(id);
  		   if(user!=null) {
  			   return user.get();
  		   }
  		   else 
  			   return null;
}
		
public List<User> getAllUsers()
{ 
		
		return userrepo.findAll() ;
	}
	@Override
	
	public List<Candidate> getAllcandidates()
	{
		
		return userrepo.findAllCandidates();
	}


	public List<Employer> getAllEmployers() {
		
		return userrepo.findAllEmployer();
	}
	
	


}
