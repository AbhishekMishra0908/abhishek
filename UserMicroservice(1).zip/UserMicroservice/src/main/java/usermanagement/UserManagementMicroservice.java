package usermanagement;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface UserManagementMicroservice
{
public boolean login(String email, String password);
public boolean register(User user);
public   User UpdateProfile(User user);
public User getUser(Integer id);
public List<Candidate> getAllcandidates();

}
