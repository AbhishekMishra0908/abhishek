package usermanagement;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class UserMicroseviceController 
{
@Autowired
private UserManagementService userservice;

/*@Autowired
private RestTemplate getRestTemplate;*/
/*@Autowired 
private Userrepo userrepo;*/
/*@RequestMapping(method=RequestMethod.POST,value ="/native/login")
public boolean loginNative(@RequestBody User user) 
{
	if(user.getEmail()!= null && user.getPassword()!=null) 
	{
		return userservice.login(user.getEmail(), user.getPassword());
	}
	else
	{

	
	return false;
	}*/


@RequestMapping(method=RequestMethod.POST,value ="/login")
public boolean login(@RequestBody User user)
{
	if(user.getEmail()!= null && user.getPassword()!=null)
	{
		return userservice.login(user.getEmail(), user.getPassword());
	}
	else
	{

	return false;
	}

}
@RequestMapping(value= "/user/add", method= RequestMethod.POST)
public Boolean register(@RequestBody User newuser)
{
    System.out.println(this.getClass().getSimpleName() + " -  method is invoked.");
    return userservice.register(newuser);
}
/*@RequestMapping(value= "/user/{userid}", method= RequestMethod.GET)
 public User getUser(@PathVariable("userid") String userid )
{
	return userservice.getUser(userid);
	
}*/
@RequestMapping(value= "/candidate/add", method= RequestMethod.POST)
public Boolean registercan(@RequestBody Candidate newcan)
{
    System.out.println(this.getClass().getSimpleName() + " -  method is invoked.");
    return userservice.registercan(newcan);
}



@RequestMapping(value= "/employer/add", method= RequestMethod.POST)
public Boolean registeremp(@RequestBody Employer newemp)
{
    System.out.println(this.getClass().getSimpleName() + " -  method is invoked.");
    return userservice.registeremp(newemp);
}
@RequestMapping(value="/getuser/{id}",method=RequestMethod.GET)
public User getUser(@PathVariable("id") Integer id, @RequestBody User user) 
{
	return userservice.getUser(id);
}
/*@RequestMapping(value="/user/update/{id}",method=RequestMethod.PUT)
public User UpdateProfile(@RequestBody User user,@PathVariable ("id") int id )
{
	userrepo.save(user);
	
	return user;
	
}*/

@RequestMapping(value = "/user/update/{id}", method = RequestMethod.PUT, headers = "Accept=application/json")
public User UpdateProfile(@RequestBody User user, @PathVariable("id") int id){
	return userservice.UpdateProfile(user);}
/*@RequestMapping(value="/user/update/{id}",method= RequestMethod.PUT)
public User UpdateProfile(@RequestBody User user, @PathVariable ("id")  int id ,@RequestParam String name,@RequestParam String email, @RequestParam String mobile,@RequestParam String password,@RequestParam String address){
	
	 User user1 =userrepo.getOne(id);
	 
     user1.setName(name);
     user1.setEmail(email);
     user1.setMobile(mobile);
     user1.setPassword(password);
     user1.setAddress(address);
     System.out.println(user1.toString());
     userrepo.save(user1);
     return user1; 
} 
*/

@RequestMapping(method=RequestMethod.GET,value ="/users/list")
public List<User> getAllUsers()
{
	return userservice.getAllUsers();
}

@RequestMapping(method=RequestMethod.GET,value ="/candidates/list")
public List<Candidate> getAllCandidates()
{
	return userservice.getAllcandidates();
}
@RequestMapping(method=RequestMethod.GET,value ="/employers/list")
public List<Employer> getAllEmployers()
{
	return userservice.getAllEmployers();
}


}