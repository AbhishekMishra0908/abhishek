package job;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="jobservice")
public class JobServiceApplication 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
private int id;
	@Column(name="jobid")
private int jobid;
@Column(name="applicationid")
private int applicationid;
public int getId()
{
	return id;
}
public void setId(int id) 
{
	this.id = id;
}
public int getJobid()
{
	return jobid;
}
public void setJobid(int jobid) 
{
	this.jobid = jobid;
}
public int getApplicationid()
{
	return applicationid;
}
public void setApplicationid(int applicationid) 
{
	this.applicationid = applicationid;
}

}
