package job;

import java.util.List;

import org.springframework.stereotype.Service;
@Service
public interface JobserviceMicroservice 
{
public Job createJob(Job job);
public Job getjob(Integer jobid);
public List<Job> getAlljobs();
public Job updatejob(Job job);
public void deletejob(Integer id);
//public List<Job> getallpublishedjobs();
public void associateApplicationWithjob(JobServiceApplication jobservapp);

}
