package job;

//import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface JobServicerepo extends CrudRepository<Job, Integer> {
//List<Job> findopenforappication(Boolean Openforapplication,Boolean Closed );
}
