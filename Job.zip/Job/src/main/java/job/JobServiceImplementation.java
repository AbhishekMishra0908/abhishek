package job;

//import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class JobServiceImplementation implements JobserviceMicroservice {
	@Autowired
private JobServicerepo jobservrepo;
	@Autowired
	private JobApplicationrepo jobapprepo;
	@Override
	public Job createJob(Job job) {
		
		return jobservrepo.save(job);
	}

	@Override
	public Job getjob(Integer jobid) {
		
		      java.util.Optional<Job> job = jobservrepo.findById(jobid);
		    		   if(job!=null) {
		    			   return job.get();
		    		   }
		    		   else 
		    			   return null;
		 
	}

	@Override
	public Job updatejob(Job job) {
		if(job.getId()<=0)
			return null;
		jobservrepo.save(job);
		return job;
	
	/*public Job updatejob(Job job) {
	
		return jobservrepo.save(job);*/
	}

/*	
	@Override
	public List<Job> getallpublishedjobs() {
		List<Job> jobs =jobservrepo.findopenforappication(true, false);
		return jobs;
	}
*/
	

	@Override
	public void deletejob(Integer id) {
		 
		 jobservrepo.deleteById(id);
		
	}
	@Override
	public void associateApplicationWithjob(JobServiceApplication jobservapp) {
		jobapprepo.save(jobservapp);
		
	}

	@Override
	public List<Job> getAlljobs() {
		
		/*Iterable <Job> jobs = jobservrepo.findAll();
		List<Job> listjob= new ArrayList<Job>();
		if(jobs != null)
		{
			for(Job job : jobs)
				listjob.add(job);
		}
		return null;*/
		return (List<Job>) jobservrepo.findAll();
	}

	public List<JobServiceApplication> getAllappliedjobs() {
		return (List<JobServiceApplication>) jobapprepo.findAll();
		
	}

}
